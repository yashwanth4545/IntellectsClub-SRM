// Intellects Club - Events View
import { showToast } from '../app.js';

export async function render(container, db, state) {
  let events = [];
  try {
    events = await db.getEvents();
  } catch (err) {
    console.error("Failed to load events:", err);
  }

  const upcomingEvents = events.filter(e => e.status === 'upcoming');
  const pastEvents = events.filter(e => e.status === 'past');

  // Generate upcoming events grid
  let upcomingHtml = '<p class="text-muted text-center" style="grid-column: 1/-1; padding: 2rem;">No upcoming workshops scheduled yet. Check back soon!</p>';
  if (upcomingEvents.length > 0) {
    upcomingHtml = upcomingEvents.map(evt => `
      <div class="glass-panel event-card">
        <div class="event-img-wrapper">
          <img src="${evt.image_url || 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?q=80&w=800'}" alt="${evt.title}" class="event-image" loading="lazy">
          <span class="event-badge upcoming">UPCOMING</span>
        </div>
        <div class="event-card-body">
          <h3 class="event-title">${evt.title}</h3>
          <p class="event-desc">${evt.description}</p>
          
          <div class="event-details-list">
            <div class="event-detail-item"><i data-lucide="calendar"></i> <span>${new Date(evt.date).toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</span></div>
            <div class="event-detail-item"><i data-lucide="clock"></i> <span>${evt.time}</span></div>
            <div class="event-detail-item"><i data-lucide="map-pin"></i> <span>${evt.venue}</span></div>
          </div>

          <button class="btn-primary btn-block register-btn" data-id="${evt.id}" data-title="${evt.title}">Register Now</button>
        </div>
      </div>
    `).join('');
  }

  // Generate past events grid
  let pastHtml = '<p class="text-muted text-center" style="grid-column: 1/-1; padding: 2rem;">No past events found.</p>';
  if (pastEvents.length > 0) {
    pastHtml = pastEvents.map(evt => `
      <div class="glass-panel event-card past">
        <div class="event-img-wrapper">
          <img src="${evt.image_url || 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?q=80&w=800'}" alt="${evt.title}" class="event-image" loading="lazy">
          <span class="event-badge past">PAST</span>
        </div>
        <div class="event-card-body">
          <h3 class="event-title">${evt.title}</h3>
          <p class="event-desc">${evt.description}</p>
          
          <div class="event-details-list">
            <div class="event-detail-item"><i data-lucide="calendar"></i> <span>${new Date(evt.date).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })}</span></div>
            <div class="event-detail-item"><i data-lucide="map-pin"></i> <span>${evt.venue}</span></div>
          </div>
        </div>
      </div>
    `).join('');
  }

  container.innerHTML = `
    <h1 class="page-title">Workshops &amp; Events</h1>
    <p class="page-subtitle">Learn by doing. Join our interactive coding labs, guest lectures, hackathons, and AI alignment seminars.</p>

    <!-- Section: Upcoming -->
    <h2 class="sub-section-title"><i data-lucide="calendar-days" class="section-icon"></i> Upcoming Sessions</h2>
    <div class="grid-cols-2 events-grid upcoming-list" style="margin-bottom: 4rem;">
      ${upcomingHtml}
    </div>

    <!-- Section: Past -->
    <h2 class="sub-section-title"><i data-lucide="history" class="section-icon"></i> Completed Sessions</h2>
    <div class="grid-cols-3 events-grid past-list">
      ${pastHtml}
    </div>

    <!-- Registration Modal Overlay (Hidden by default) -->
    <div id="registration-modal" class="modal-overlay hidden">
      <div class="glass-panel modal-card">
        <button class="modal-close-btn" aria-label="Close modal"><i data-lucide="x"></i></button>
        <h2 class="modal-title" style="font-family: var(--font-heading);">Register for Event</h2>
        <p class="modal-subtitle" id="modal-event-title" style="color: var(--primary-glow); font-weight: 600; margin-bottom: 1.5rem;"></p>
        
        <form id="event-reg-form">
          <input type="hidden" id="reg-event-id">
          
          <div class="form-group">
            <label for="reg-name" class="form-label">Full Name</label>
            <input type="text" id="reg-name" class="form-control" placeholder="Enter your full name" required>
          </div>

          <div class="form-group">
            <label for="reg-email" class="form-label">Official Email</label>
            <input type="email" id="reg-email" class="form-control" placeholder="example@srmist.edu.in" required>
          </div>

          <div class="grid-cols-2" style="gap: 1rem; margin-bottom: 0;">
            <div class="form-group">
              <label for="reg-number" class="form-label">Registration Number</label>
              <input type="text" id="reg-number" class="form-control" placeholder="RAXXXXXXXXXXXXX" required>
            </div>
            
            <div class="form-group">
              <label for="reg-year" class="form-label">Year of Study</label>
              <select id="reg-year" class="form-control" required>
                <option value="" disabled selected>Select Year</option>
                <option value="1">1st Year</option>
                <option value="2">2nd Year</option>
                <option value="3">3rd Year</option>
                <option value="4">4th Year</option>
              </select>
            </div>
          </div>

          <div class="form-group">
            <label for="reg-dept" class="form-label">Department / Branch</label>
            <input type="text" id="reg-dept" class="form-control" placeholder="e.g. CSE (AIML)" required>
          </div>

          <button type="submit" class="btn-primary btn-block" style="margin-top: 1rem;">Confirm Seat Registration</button>
        </form>
      </div>
    </div>
  `;

  // Attach Modal Event Listeners
  const modal = container.querySelector('#registration-modal');
  const closeBtn = container.querySelector('.modal-close-btn');
  const regForm = container.querySelector('#event-reg-form');
  const regEventIdInput = container.querySelector('#reg-event-id');
  const modalEventTitle = container.querySelector('#modal-event-title');

  // Opening the Modal
  container.querySelectorAll('.register-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const eventId = btn.getAttribute('data-id');
      const eventTitle = btn.getAttribute('data-title');
      
      regEventIdInput.value = eventId;
      modalEventTitle.innerText = eventTitle;
      
      modal.classList.remove('hidden');
      gsap.fromTo(modal, { opacity: 0 }, { opacity: 1, duration: 0.3 });
      gsap.fromTo('.modal-card', { y: 30, opacity: 0 }, { y: 0, opacity: 1, duration: 0.4, ease: 'power3.out' });
    });
  });

  // Closing the Modal
  const closeModalFunc = () => {
    gsap.to('.modal-card', {
      y: 20,
      opacity: 0,
      duration: 0.3,
      onComplete: () => {
        gsap.to(modal, {
          opacity: 0,
          duration: 0.2,
          onComplete: () => {
            modal.classList.add('hidden');
            regForm.reset();
          }
        });
      }
    });
  };

  closeBtn.addEventListener('click', closeModalFunc);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModalFunc();
  });

  // Handle Form Submission
  regForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const payload = {
      event_id: regEventIdInput.value,
      full_name: container.querySelector('#reg-name').value,
      email: container.querySelector('#reg-email').value,
      register_number: container.querySelector('#reg-number').value,
      year_of_study: parseInt(container.querySelector('#reg-year').value, 10),
      department: container.querySelector('#reg-dept').value
    };

    try {
      await db.registerForEvent(payload);
      showToast("Registration successful! Seat confirmed.", "success");
      closeModalFunc();
    } catch (err) {
      showToast(err.message || "Failed to register. Please check details.", "error");
    }
  });

  // Entrance animations
  gsap.from('.upcoming-list > *', { opacity: 0, scale: 0.95, stagger: 0.1, duration: 0.5 });
  gsap.from('.past-list > *', { opacity: 0, y: 20, stagger: 0.08, duration: 0.5 });
}
