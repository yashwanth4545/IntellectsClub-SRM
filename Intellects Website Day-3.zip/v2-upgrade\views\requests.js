// Intellects Club - Membership Request View
import { showToast } from '../app.js';

export async function render(container, db, state) {
  const skillsList = ["Python", "TensorFlow / PyTorch", "Data Science", "HTML / CSS", "JavaScript / React", "Node.js / Go", "UI/UX Design", "Research & Writing", "Hardware & IoT", "Public Speaking"];

  const skillsHtml = skillsList.map(skill => `
    <label class="checkbox-tag-label">
      <input type="checkbox" name="skills" value="${skill}">
      <span class="checkbox-tag-content">${skill}</span>
    </label>
  `).join('');

  container.innerHTML = `
    <h1 class="page-title">Join the Movement</h1>
    <p class="page-subtitle">Ready to learn beyond the classroom? Apply to join Intellects Club. We review applications on a rolling basis.</p>

    <div class="glass-panel form-container" style="max-width: 650px; margin: 0 auto;">
      <h2 style="font-family: var(--font-heading); font-size: 1.75rem; margin-bottom: 0.5rem; text-align: center;">Membership Application</h2>
      <p style="color: var(--text-secondary); font-size: 0.9rem; text-align: center; margin-bottom: 2rem;">Please fill out this form honestly. No prior AI experience is required – curiosity and dedication are what we value most.</p>

      <form id="membership-form">
        <div class="form-group">
          <label for="req-fullname" class="form-label">Full Name</label>
          <input type="text" id="req-fullname" class="form-control" placeholder="Enter your full name" required>
        </div>

        <div class="form-group">
          <label for="req-email" class="form-label">Email Address</label>
          <input type="email" id="req-email" class="form-control" placeholder="example@srmist.edu.in" required>
        </div>

        <div class="grid-cols-2" style="gap: 1.5rem; margin-bottom: 0;">
          <div class="form-group">
            <label for="req-reg" class="form-label">Registration Number</label>
            <input type="text" id="req-reg" class="form-control" placeholder="RAXXXXXXXXXXXXX" required>
          </div>
          
          <div class="form-group">
            <label class="form-label">Year of Study</label>
            <div class="checkbox-tag-group year-tag-group">
              <label class="checkbox-tag-label">
                <input type="radio" name="year_of_study" value="1">
                <span class="checkbox-tag-content">1st Year</span>
              </label>
              <label class="checkbox-tag-label">
                <input type="radio" name="year_of_study" value="2">
                <span class="checkbox-tag-content">2nd Year</span>
              </label>
              <label class="checkbox-tag-label">
                <input type="radio" name="year_of_study" value="3">
                <span class="checkbox-tag-content">3rd Year</span>
              </label>
              <label class="checkbox-tag-label">
                <input type="radio" name="year_of_study" value="4">
                <span class="checkbox-tag-content">4th Year</span>
              </label>
            </div>
            <div id="year-error" style="display: none; color: #fca5a5; font-size: 0.85rem; margin-top: 0.5rem; background: rgba(239, 68, 68, 0.15); padding: 0.4rem 0.8rem; border-radius: 6px; border: 1px solid rgba(239, 68, 68, 0.3);">
              <i data-lucide="alert-circle" style="width: 14px; height: 14px; display: inline-block; vertical-align: middle; margin-right: 4px;"></i> Please select your year of study.
            </div>
          </div>
        </div>

        <div class="form-group">
          <label for="req-dept" class="form-label">Department / Branch</label>
          <input type="text" id="req-dept" class="form-control" placeholder="e.g. CSE (Cyber Security)" required>
        </div>

        <div class="form-group">
          <label class="form-label">Primary Technical Interest / Skills (Select all that apply)</label>
          <div class="checkbox-tag-group">
            ${skillsHtml}
          </div>
        </div>

        <div class="form-group">
          <label for="req-interest" class="form-label">Why do you want to join Intellects Club?</label>
          <textarea id="req-interest" class="form-control" placeholder="Describe what projects you hope to work on, what skills you wish to learn, or how you want to contribute to the community." required></textarea>
        </div>

        <button type="submit" class="btn-primary btn-block" style="margin-top: 1rem; font-size: 1.1rem; padding: 0.8rem;"><i data-lucide="send" class="nav-icon"></i> Submit Application</button>
      </form>
    </div>
  `;

  const form = container.querySelector('#membership-form');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const yearSelected = container.querySelector('input[name="year_of_study"]:checked');
    const yearError = container.querySelector('#year-error');
    if (!yearSelected) {
      yearError.style.display = 'block';
      return; // Stop submission
    } else {
      yearError.style.display = 'none';
    }

    // Collect skills
    const selectedSkills = [];
    container.querySelectorAll('input[name="skills"]:checked').forEach(cb => {
      selectedSkills.push(cb.value);
    });

    const payload = {
      full_name: container.querySelector('#req-fullname').value,
      email: container.querySelector('#req-email').value,
      register_number: container.querySelector('#req-reg').value,
      year_of_study: parseInt(yearSelected.value, 10),
      department: container.querySelector('#req-dept').value,
      skills: selectedSkills,
      interest_statement: container.querySelector('#req-interest').value
    };

    try {
      await db.submitRequest(payload);
      showToast("Application submitted successfully! Check your mail for updates.", "success");
      form.reset();
      
      // Redirect to home after short delay
      setTimeout(() => {
        window.location.hash = '#/';
      }, 1500);

    } catch (err) {
      showToast(err.message || "Failed to submit request.", "error");
    }
  });

  // Entrance animation for form container
  gsap.from('.form-container', {
    opacity: 0,
    y: 30,
    duration: 0.6,
    ease: 'power3.out'
  });
}
