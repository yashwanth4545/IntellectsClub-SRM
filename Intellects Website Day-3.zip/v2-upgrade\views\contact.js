// Intellects Club - Contact View
import { showToast } from '../app.js';

export async function render(container, db, state) {
  container.innerHTML = `
    <h1 class="page-title">Connect with Us</h1>
    <p class="page-subtitle">Have a question? Interested in sponsoring us or collaborating on an AI event? Reach out directly.</p>

    <div class="grid-cols-2 contact-layout">
      <!-- Contact Info Section -->
      <div class="glass-panel contact-info-panel">
        <h2 style="font-family: var(--font-heading); margin-bottom: 1.5rem;">Contact Information</h2>
        
        <div class="contact-details-list">
          <div class="contact-info-item">
            <div class="contact-icon"><i data-lucide="map-pin"></i></div>
            <div class="contact-text">
              <h3>Our Location</h3>
              <p>SRM Institute of Science and Technology, Ramapuram Campus, Bharathi Salai, Ramapuram, Chennai, Tamil Nadu 600089</p>
            </div>
          </div>

          <div class="contact-info-item">
            <div class="contact-icon"><i data-lucide="mail"></i></div>
            <div class="contact-text">
              <h3>Email Queries</h3>
              <p><a href="mailto:intellectsclub.rmp@gmail.com" style="color: var(--primary-glow); text-decoration: none;">intellectsclub.rmp@gmail.com</a></p>
            </div>
          </div>

          <div class="contact-info-item">
            <div class="contact-icon"><i data-lucide="calendar"></i></div>
            <div class="contact-text">
              <h3>Club Sessions</h3>
              <p>Every Friday, 2:00 PM — 4:00 PM at Tech Lab 3 &amp; Block V Seminar Hall.</p>
            </div>
          </div>
        </div>

        <!-- Inline SVG Map representation or location card -->
        <div class="mock-map glass-panel" style="margin-top: 2rem; padding: 1.5rem; text-align: center; border-color: rgba(168, 85, 247, 0.1);">
          <i data-lucide="map" style="width: 36px; height: 36px; color: var(--accent-blue); margin-bottom: 0.5rem;"></i>
          <h3>SRM Ramapuram Campus Guide</h3>
          <p style="font-size: 0.85rem; color: var(--text-secondary);">Block V (IT &amp; CSE Dept), Third Floor, Lab 3</p>
        </div>
      </div>

      <!-- Contact Form Section -->
      <div class="glass-panel contact-form-panel">
        <h2 style="font-family: var(--font-heading); margin-bottom: 1rem;">Send a Message</h2>
        <p style="color: var(--text-secondary); font-size: 0.9rem; margin-bottom: 1.5rem;">Fill out the form below and the core board will get back to you within 24 hours.</p>

        <form id="contact-form">
          <div class="form-group">
            <label for="contact-name" class="form-label">Name</label>
            <input type="text" id="contact-name" class="form-control" placeholder="Your full name" required>
          </div>

          <div class="form-group">
            <label for="contact-email" class="form-label">Email Address</label>
            <input type="email" id="contact-email" class="form-control" placeholder="example@srmist.edu.in" required>
          </div>

          <div class="form-group">
            <label for="contact-subject" class="form-label">Subject</label>
            <input type="text" id="contact-subject" class="form-control" placeholder="What are you writing about?" required>
          </div>

          <div class="form-group">
            <label for="contact-msg" class="form-label">Message</label>
            <textarea id="contact-msg" class="form-control" placeholder="Type your message here..." required></textarea>
          </div>

          <button type="submit" class="btn-primary btn-block"><i data-lucide="send" class="nav-icon"></i> Send Message</button>
        </form>
      </div>
    </div>
  `;

  const form = container.querySelector('#contact-form');
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    
    // Simulate API request
    showToast("Message sent successfully! Thank you.", "success");
    form.reset();
  });

  // Entrance animations
  gsap.from('.contact-info-panel', { opacity: 0, x: -30, duration: 0.6, ease: 'power2.out' });
  gsap.from('.contact-form-panel', { opacity: 0, x: 30, duration: 0.6, ease: 'power2.out' });
}
