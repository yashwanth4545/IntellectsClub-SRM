// Intellects Club - Home View
import { showToast } from '../app.js';

export async function render(container, db, state) {
  // Fetch latest announcements
  let announcements = [];
  try {
    announcements = await db.getAnnouncements();
  } catch (err) {
    console.error("Failed to load announcements:", err);
  }

  const upcomingEventsHtml = ''; // Can fetch events and show spotlight

  // Generate Announcements HTML
  let announcementsHtml = '<p class="text-muted">No active announcements at the moment.</p>';
  if (announcements.length > 0) {
    announcementsHtml = announcements.map(ann => `
      <div class="announcement-item ${ann.type}">
        <div class="ann-icon">
          <i data-lucide="${ann.type === 'success' ? 'check-circle' : ann.type === 'warning' ? 'alert-circle' : 'info'}"></i>
        </div>
        <div class="ann-content">
          <h4 class="ann-title">${ann.title}</h4>
          <p class="ann-text">${ann.content}</p>
          <span class="ann-date">${new Date(ann.created_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</span>
        </div>
      </div>
    `).join('');
  }

  container.innerHTML = `
    <!-- Home Hero Section -->
    <section class="home-hero blur-entry">
      <div class="hero-lens-glow"></div>
      <div class="hero-portal-glass"></div>
      <div class="hero-logo-hierarchy">
        <div class="glass-medallion">
            <img src="assets/club-logo-notext.png" alt="Intellects Club Logo">
        </div>
        <div class="holographic-badge">
            <img src="assets/srm-logo.png" alt="SRM Institute">
        </div>
      </div>

      <h1 class="hero-heading">INTELLECTS CLUB</h1>
      <p class="hero-subtext">SRM Institute of Science and Technology, Ramapuram</p>
      <p class="hero-tagline">Where curiosity meets computational intelligence. We build real skills, create future prototypes, and push the boundaries of Artificial Intelligence.</p>
      
      <div class="hero-actions">
        <a href="#/requests" class="btn-primary">Apply for Membership</a>
        <a href="#/events" class="btn-secondary">Explore Workshops</a>
      </div>
    </section>

    <!-- Quick Stats counter panels -->
    <section class="stats-section grid-cols-3">
      <div class="glass-panel stat-card text-center">
        <div class="stat-icon-wrapper purple"><i data-lucide="users"></i></div>
        <h3 class="stat-number" data-target="500">500+</h3>
        <p class="stat-label">Active Student Members</p>
      </div>
      <div class="glass-panel stat-card text-center">
        <div class="stat-icon-wrapper pink"><i data-lucide="laptop"></i></div>
        <h3 class="stat-number" data-target="25">25+</h3>
        <p class="stat-label">Hands-on Workshops</p>
      </div>
      <div class="glass-panel stat-card text-center">
        <div class="stat-icon-wrapper blue"><i data-lucide="award"></i></div>
        <h3 class="stat-number" data-target="30">30+</h3>
        <p class="stat-label">Hackathon Victories</p>
      </div>
    </section>

    <!-- Core Content Split Grid -->
    <div class="grid-cols-2 home-split-container">
      <!-- Mission Statement panel -->
      <section class="glass-panel mission-panel">
        <div class="section-badge"><i data-lucide="compass"></i> MISSION &amp; VISION</div>
        <h2 class="section-title">Beyond Classroom Learning</h2>
        <p class="mission-text">
          Intellects Club is built for students who want to move beyond classroom learning and turn curiosity into real skills. We create a dedicated collaborative space where beginners, builders, designers, researchers, and problem-solvers can explore artificial intelligence, software development, innovation, and emerging technology.
        </p>
        <p class="mission-text">
          By engaging in hands-on building, practical workshops, peer mentoring, and hackathons, our members grow from simple coders into creative, future-ready innovators capable of solving complex problems with meaningful solutions.
        </p>
        <a href="#/about" class="btn-secondary" style="margin-top: 1rem; display: inline-flex; align-items: center; gap: 0.5rem;">
          Read Our Full Story <i data-lucide="arrow-right" class="nav-icon"></i>
        </a>
      </section>

      <!-- Announcements Bulletin panel -->
      <section class="glass-panel announcements-panel">
        <div class="section-badge"><i data-lucide="bell"></i> ANNOUNCEMENTS</div>
        <h2 class="section-title">Latest Updates</h2>
        <div class="announcements-list">
          ${announcementsHtml}
        </div>
      </section>
    </div>
  `;

  // Register ScrollTrigger with GSAP
  if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
    gsap.registerPlugin(ScrollTrigger);
  }

  // Animate stats numbers counting up using rAF (no setInterval drift)
  const statNumbers = container.querySelectorAll('.stat-number');
  statNumbers.forEach(stat => {
    const target = parseInt(stat.getAttribute('data-target'), 10);
    const hasSuffix = stat.innerText.includes('+') ? '+' : '';
    const duration = 1200;
    const startTime = performance.now();
    function tick(now) {
      const progress = Math.min((now - startTime) / duration, 1);
      const eased = 1 - (1 - progress) * (1 - progress);
      stat.textContent = Math.floor(eased * target) + hasSuffix;
      if (progress < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  });

  // GSAP animation triggers for entry
  if (typeof gsap !== 'undefined') {
    gsap.from('.home-hero > *', {
      opacity: 0,
      y: 20,
      stagger: 0.1,
      duration: 0.6,
      ease: 'power3.out'
    });

    if (typeof ScrollTrigger !== 'undefined') {
      gsap.from('.stat-card', {
        opacity: 0,
        y: 30,
        stagger: 0.1,
        duration: 0.5,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: '.stats-section',
          start: 'top 85%'
        }
      });
    }
  }
}
