// Intellects Club - Resources & Roadmaps View

export async function render(container, db, state) {
  container.innerHTML = `
    <h1 class="page-title">AI Resource Hub</h1>
    <p class="page-subtitle">Interactive learning roadmaps and the session vault for all Intellects Club materials.</p>

    <div class="filter-tabs-wrapper" style="margin-bottom: 2rem;">
        <button class="filter-tab active" id="tab-roadmap">Learning Roadmaps</button>
        <button class="filter-tab" id="tab-vault">Session Vault</button>
    </div>

    <!-- Roadmaps Section -->
    <div id="section-roadmap" class="resource-section">
        <h2 style="font-family: var(--font-heading); text-align: center; margin-bottom: 2rem;">The Path to AI Engineering</h2>
        
        <div class="roadmap-timeline" style="max-width: 800px; margin: 0 auto; position: relative;">
            <div style="position: absolute; left: 20px; top: 0; bottom: 0; width: 2px; background: linear-gradient(180deg, var(--primary-glow), var(--accent-pink));"></div>
            
            <div class="roadmap-node" style="position: relative; margin-bottom: 2rem; padding-left: 50px;">
                <div style="position: absolute; left: 11px; top: 0; width: 20px; height: 20px; border-radius: 50%; background: #000; border: 2px solid var(--primary-glow); box-shadow: var(--glow-shadow);"></div>
                <div class="glass-panel" style="padding: 1.5rem;">
                    <h3 style="color: var(--primary-glow); margin-bottom: 0.5rem;">Phase 1: Foundations (Python & Math)</h3>
                    <p style="color: var(--text-secondary); font-size: 0.9rem;">Mastering data structures, object-oriented programming, Linear Algebra, and Calculus basics.</p>
                </div>
            </div>

            <div class="roadmap-node" style="position: relative; margin-bottom: 2rem; padding-left: 50px;">
                <div style="position: absolute; left: 11px; top: 0; width: 20px; height: 20px; border-radius: 50%; background: #000; border: 2px solid var(--primary-glow); box-shadow: var(--glow-shadow);"></div>
                <div class="glass-panel" style="padding: 1.5rem;">
                    <h3 style="color: var(--primary-glow); margin-bottom: 0.5rem;">Phase 2: Machine Learning</h3>
                    <p style="color: var(--text-secondary); font-size: 0.9rem;">Scikit-learn, Regression, Classification, SVMs, and Random Forests.</p>
                </div>
            </div>

            <div class="roadmap-node" style="position: relative; margin-bottom: 2rem; padding-left: 50px;">
                <div style="position: absolute; left: 11px; top: 0; width: 20px; height: 20px; border-radius: 50%; background: #000; border: 2px solid var(--accent-pink); box-shadow: 0 0 10px var(--accent-pink);"></div>
                <div class="glass-panel" style="padding: 1.5rem; border-color: rgba(217, 70, 239, 0.3);">
                    <h3 style="color: var(--accent-pink); margin-bottom: 0.5rem;">Phase 3: Deep Learning (PyTorch)</h3>
                    <p style="color: var(--text-secondary); font-size: 0.9rem;">Neural Networks, CNNs for Vision, RNNs, and Backpropagation.</p>
                </div>
            </div>
            
            <div class="roadmap-node" style="position: relative; padding-left: 50px;">
                <div style="position: absolute; left: 11px; top: 0; width: 20px; height: 20px; border-radius: 50%; background: #000; border: 2px solid var(--accent-blue); box-shadow: 0 0 10px var(--accent-blue);"></div>
                <div class="glass-panel" style="padding: 1.5rem; border-color: rgba(14, 165, 233, 0.3);">
                    <h3 style="color: var(--accent-blue); margin-bottom: 0.5rem;">Phase 4: Advanced GenAI & LLMs</h3>
                    <p style="color: var(--text-secondary); font-size: 0.9rem;">Transformers, Stable Diffusion, RAG, and LangChain agents.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Vault Section -->
    <div id="section-vault" class="resource-section" style="display: none;">
        <div class="grid-cols-2">
            <div class="glass-panel" style="border-top: 3px solid var(--primary-glow);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                    <h3 style="font-family: var(--font-heading);">Intro to Neural Networks</h3>
                    <span class="status-badge approved">Session 4</span>
                </div>
                <p style="color: var(--text-secondary); font-size: 0.9rem; margin-bottom: 1rem;">Slides and PyTorch notebook for the backpropagation fundamentals session.</p>
                <div style="display: flex; gap: 1rem;">
                    <button class="btn-action" style="width: auto; padding: 0.5rem 1rem;"><i data-lucide="download" style="width: 14px;"></i> Slides (PDF)</button>
                    <button class="btn-action" style="width: auto; padding: 0.5rem 1rem;"><i data-lucide="github" style="width: 14px;"></i> Colab Notebook</button>
                </div>
            </div>

            <div class="glass-panel" style="border-top: 3px solid var(--accent-pink);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                    <h3 style="font-family: var(--font-heading);">Computer Vision Bootcamp</h3>
                    <span class="status-badge approved">Session 3</span>
                </div>
                <p style="color: var(--text-secondary); font-size: 0.9rem; margin-bottom: 1rem;">OpenCV basics and building a face detection model from scratch.</p>
                <div style="display: flex; gap: 1rem;">
                    <button class="btn-action" style="width: auto; padding: 0.5rem 1rem;"><i data-lucide="download" style="width: 14px;"></i> Slides (PDF)</button>
                    <button class="btn-action" style="width: auto; padding: 0.5rem 1rem;"><i data-lucide="github" style="width: 14px;"></i> Colab Notebook</button>
                </div>
            </div>
        </div>
    </div>
  `;

  const tabRoadmap = container.querySelector('#tab-roadmap');
  const tabVault = container.querySelector('#tab-vault');
  const sectionRoadmap = container.querySelector('#section-roadmap');
  const sectionVault = container.querySelector('#section-vault');

  tabRoadmap.addEventListener('click', () => {
      tabVault.classList.remove('active');
      tabRoadmap.classList.add('active');
      sectionVault.style.display = 'none';
      sectionRoadmap.style.display = 'block';
      gsap.fromTo('.roadmap-node', {opacity: 0, x: -30}, {opacity: 1, x: 0, stagger: 0.15, duration: 0.5});
  });

  tabVault.addEventListener('click', () => {
      tabRoadmap.classList.remove('active');
      tabVault.classList.add('active');
      sectionRoadmap.style.display = 'none';
      sectionVault.style.display = 'block';
      gsap.fromTo('#section-vault .glass-panel', {opacity: 0, y: 30}, {opacity: 1, y: 0, stagger: 0.15, duration: 0.5});
  });

  // Entrance animation
  gsap.from('.roadmap-node', {
      opacity: 0,
      x: -30,
      stagger: 0.15,
      duration: 0.6,
      ease: 'power3.out'
  });
}
