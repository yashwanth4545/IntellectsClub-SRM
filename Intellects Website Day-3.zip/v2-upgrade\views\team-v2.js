// Intellects Club - Team View

export async function render(container, db, state) {
  let team = [];
  try {
    team = await db.getTeam();
  } catch (err) {
    console.error("Failed to load team data:", err);
  }

  const teamHtml = team.map(member => {
    const badgeText = member.specialTag || (member.siteCreator ? 'Site Creator' : '');
    const badge = badgeText ? `
      <div class="site-creator-badge">
        <i data-lucide="code-2" style="width:12px;height:12px;"></i>
        <span>${badgeText}</span>
      </div>
    ` : '';

    return `
      <div class="glass-panel team-card ${member.siteCreator ? 'team-card--creator' : ''}">
        ${badge}
        <div class="team-image-container">
          <img src="${member.image}" alt="${member.name}" class="team-image" loading="lazy">
          <div class="team-overlay-glow"></div>
        </div>
        <h3 class="team-name">${member.name}</h3>
        <div class="team-role-badge">${member.role}</div>
        <p class="team-desc">${member.description || ''}</p>
        <div class="team-socials">
          ${member.linkedin ? `<a href="${member.linkedin}" target="_blank" aria-label="${member.name} LinkedIn Profile" class="team-social-link linkedin"><i data-lucide="linkedin"></i></a>` : ''}
          ${member.github ? `<a href="${member.github}" target="_blank" aria-label="${member.name} GitHub Profile" class="team-social-link github"><i data-lucide="github"></i></a>` : ''}
        </div>
      </div>
    `;
  }).join('');

  container.innerHTML = `
    <h1 class="page-title">Core Board &amp; Mentors</h1>
    <p class="page-subtitle">Meet the team of students, developers, and advisors driving artificial intelligence and engineering excellence at SRM Ramapuram.</p>

    <div class="team-grid-uniform">
      ${teamHtml}
    </div>
  `;



}
