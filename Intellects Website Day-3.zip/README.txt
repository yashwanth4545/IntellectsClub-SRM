Intellects Website Day-3 Updates
================================

Today's work focused on advanced performance optimization, UX refinement, and bug fixes:

1. Performance Enhancements:
   - Reduced 3D galaxy particles for significant GPU savings.
   - Disabled anti-aliasing and enabled low-power preference for the WebGL renderer.
   - Throttled input events to avoid excessive frame recalculations.
   - Added Page Visibility API to pause rendering when the tab is inactive.
   - Changed stat counters to requestAnimationFrame for smooth animations.
   
2. Network & Loading Optimization:
   - Removed aggressive cache-busting to utilize browser module caching.
   - Added lazy loading to images.
   
3. Bug Fixes & UX:
   - Deduplicated VanillaTilt initialization.
   - Optimized custom cursor animation.
   - Fixed MutationObserver memory leak.
   - Removed a heavy blur filter from page transitions.
   - Cropped text from the main glass medallion logo.

4. Deployment:
   - Successfully deployed the v2-upgrade build.

5. Project Security Features Overview:
   - Database Firewall (RLS): Supabase Row Level Security blocks unauthorized database access. Only admins can edit events/projects; users can only edit their own data.
   - User Authentication: Supabase Auth securely manages passwords and Google logins without storing plain text.
   - Role-Based Access Control (RBAC): Profiles have 'admin' or 'member' roles, separating leader access from student access.
   - Protected Pages: Frontend route guards block logged-out users from accessing private dashboards.
   - Automated Secure Triggers: Database triggers automatically and securely generate profiles on signup.
   - Cache Security: Firebase Hosting headers block caching of sensitive JS code on shared lab computers.
