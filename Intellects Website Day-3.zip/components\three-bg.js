// Intellects Club - Three.js Particle Background Component
// Performance-optimized: reduced particles, disabled antialiasing, Page Visibility pause, throttled input

export function initThreeBackground() {
  const canvas = document.getElementById('three-canvas');
  if (!canvas) return;

  // Detect low-powered devices (mobile) and skip heavy 3D entirely
  const isMobile = window.innerWidth < 768 || /Android|iPhone|iPad/i.test(navigator.userAgent);

  let scene, camera, renderer, particles;
  let mouseX = 0, mouseY = 0;
  let targetX = 0, targetY = 0;
  let animFrameId = null;
  let isPaused = false;

  // Throttle mouse/touch so we don't recalculate on every pixel move
  let lastInputTime = 0;
  const INPUT_THROTTLE_MS = 30;

  const windowHalfX = window.innerWidth / 2;
  const windowHalfY = window.innerHeight / 2;

  // Initialize Three.js scene
  function init() {
    scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x05020a, 0.001);

    camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 1, 1000);
    camera.position.z = 400;

    // Fewer particles on mobile, reduced on desktop for smooth 60fps
    const particleCount = isMobile ? 400 : 800;
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);

    const color1 = new THREE.Color(0xa855f7); // Purple glow
    const color2 = new THREE.Color(0xec4899); // Pink accent
    const color3 = new THREE.Color(0x06b6d4); // Cyan tint

    for (let i = 0; i < particleCount * 3; i += 3) {
      positions[i]     = (Math.random() - 0.5) * 1200;
      positions[i + 1] = (Math.random() - 0.5) * 1200;
      positions[i + 2] = (Math.random() - 0.5) * 1000;

      const rand = Math.random();
      const mixedColor = rand < 0.4 ? color1 : rand < 0.8 ? color2 : color3;
      colors[i]     = mixedColor.r;
      colors[i + 1] = mixedColor.g;
      colors[i + 2] = mixedColor.b;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color',    new THREE.BufferAttribute(colors, 3));

    const material = new THREE.PointsMaterial({
      size: isMobile ? 2.5 : 3.5,
      vertexColors: true,
      transparent: true,
      opacity: 0.55,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      map: createCircleTexture()
    });

    particles = new THREE.Points(geometry, material);
    scene.add(particles);

    // antialias: false — huge GPU win, barely visible difference with particle effects
    renderer = new THREE.WebGLRenderer({ canvas, antialias: false, alpha: true, powerPreference: 'low-power' });
    // Cap pixel ratio to 1.5 — 2x is rarely worth the 4x fill-rate cost
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
    renderer.setSize(window.innerWidth, window.innerHeight);

    window.addEventListener('resize', onWindowResize);
    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('touchmove', onTouchMove, { passive: true });

    // Pause rendering when the browser tab is hidden
    document.addEventListener('visibilitychange', onVisibilityChange);

    animate();
  }

  function createCircleTexture() {
    const matCanvas = document.createElement('canvas');
    matCanvas.width = 16;
    matCanvas.height = 16;
    const ctx = matCanvas.getContext('2d');
    const gradient = ctx.createRadialGradient(8, 8, 0, 8, 8, 8);
    gradient.addColorStop(0,   'rgba(255, 255, 255, 1)');
    gradient.addColorStop(0.5, 'rgba(255, 255, 255, 0.4)');
    gradient.addColorStop(1,   'rgba(255, 255, 255, 0)');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 16, 16);
    return new THREE.CanvasTexture(matCanvas);
  }

  function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  }

  function onMouseMove(event) {
    const now = performance.now();
    if (now - lastInputTime < INPUT_THROTTLE_MS) return;
    lastInputTime = now;
    targetX = (event.clientX - windowHalfX) * 0.15;
    targetY = (event.clientY - windowHalfY) * 0.15;
  }

  function onTouchMove(event) {
    const now = performance.now();
    if (now - lastInputTime < INPUT_THROTTLE_MS) return;
    lastInputTime = now;
    if (event.touches.length === 1) {
      targetX = (event.touches[0].pageX - windowHalfX) * 0.15;
      targetY = (event.touches[0].pageY - windowHalfY) * 0.15;
    }
  }

  function onVisibilityChange() {
    isPaused = document.hidden;
    if (!isPaused && !animFrameId) {
      animate(); // Resume if was paused
    }
  }

  function animate() {
    if (isPaused) {
      animFrameId = null;
      return;
    }
    animFrameId = requestAnimationFrame(animate);

    mouseX += (targetX - mouseX) * 0.05;
    mouseY += (targetY - mouseY) * 0.05;

    const time = Date.now() * 0.00005;
    particles.rotation.y = time * 0.5  + mouseX * 0.001;
    particles.rotation.x = time * 0.25 + mouseY * 0.001;

    renderer.render(scene, camera);
  }

  init();
}
