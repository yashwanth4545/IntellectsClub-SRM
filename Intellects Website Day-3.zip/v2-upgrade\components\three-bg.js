// Intellects Club - V14 Neural Network Particle Galaxy
import * as THREE from 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.module.js';

export function initThreeBackground() {
  const canvas = document.getElementById('three-canvas');
  if (!canvas) return;

  const isMobile = window.innerWidth <= 768;
  const pixelRatio = isMobile ? 1 : Math.min(window.devicePixelRatio, 1.5);

  let animFrameId = null;
  let isPaused = false;

  // Throttle mouse/touch input to max 30 fps worth of recalculations
  let lastInputTime = 0;
  const INPUT_THROTTLE = 33; // ms

  let scene, camera, renderer;
  let particleGalaxy;
  
  // Neural Network Constellation Layer
  let interactiveNodes;
  let linesMesh;
  const nodeCount = isMobile ? 80 : 250;
  let nodesData = [];
  let linesGeometry;
  
  // Interaction variables
  let mouseX = 0, mouseY = 0, targetX = 0, targetY = 0;
  let scrollY = 0, targetScrollY = 0;
  // Normalized mouse coordinates for neural net intersection
  let pointerX = 0, pointerY = 0;

  const windowHalfX = window.innerWidth / 2;
  const windowHalfY = window.innerHeight / 2;

  
  let planetsGroup;
  let nebulaParticles;

  const textureLoader = new THREE.TextureLoader();
  const earthTex = textureLoader.load('https://raw.githubusercontent.com/mrdoob/three.js/master/examples/textures/planets/earth_atmos_2048.jpg');
  const earthSpec = textureLoader.load('https://raw.githubusercontent.com/mrdoob/three.js/master/examples/textures/planets/earth_specular_2048.jpg');
  const earthClouds = textureLoader.load('https://raw.githubusercontent.com/mrdoob/three.js/master/examples/textures/planets/earth_clouds_1024.png');
  const moonTex = textureLoader.load('https://raw.githubusercontent.com/mrdoob/three.js/master/examples/textures/planets/moon_1024.jpg');

  function createPlanets() {
      planetsGroup = new THREE.Group();
      scene.add(planetsGroup);

      // Distant Sun Glow to justify lighting
      const sunLight = new THREE.PointLight(0xfff7e6, 2, 4000);
      sunLight.position.set(1500, 500, -1500);
      scene.add(sunLight);
      
      const sunGeo = new THREE.SphereGeometry(150, 32, 32);
      const sunMat = new THREE.MeshBasicMaterial({ color: 0xfff7e6, transparent: true, opacity: 0.8 });
      const sunMesh = new THREE.Mesh(sunGeo, sunMat);
      sunLight.add(sunMesh);

      // Soft ambient
      const ambLight = new THREE.AmbientLight(0x404040, 0.3); 
      scene.add(ambLight);

      // 1. Earth-like Planet
      const earthGeo = new THREE.SphereGeometry(220, 64, 64);
      const earthMat = new THREE.MeshPhongMaterial({
          map: earthTex,
          specularMap: earthSpec,
          specular: new THREE.Color('grey'),
          shininess: 15
      });
      const earth = new THREE.Mesh(earthGeo, earthMat);
      // Position Earth on the right side, away from center text
      earth.position.set(900, 0, -700); 
      
      // Cloud layer
      const cloudGeo = new THREE.SphereGeometry(223, 64, 64);
      const cloudMat = new THREE.MeshLambertMaterial({
          map: earthClouds,
          transparent: true,
          opacity: 0.6,
          blending: THREE.AdditiveBlending,
          side: THREE.DoubleSide
      });
      const cloudMesh = new THREE.Mesh(cloudGeo, cloudMat);
      earth.add(cloudMesh);
      
      // Atmosphere Glow
      const atmoGeo = new THREE.SphereGeometry(230, 64, 64);
      const atmoMat = new THREE.MeshBasicMaterial({
          color: 0x38bdf8,
          transparent: true,
          opacity: 0.2,
          blending: THREE.AdditiveBlending,
          side: THREE.BackSide
      });
      const atmo = new THREE.Mesh(atmoGeo, atmoMat);
      earth.add(atmo);
      planetsGroup.add(earth);

      // 2. Realistic Moon
      const moonGeo = new THREE.SphereGeometry(50, 32, 32);
      const moonMat = new THREE.MeshStandardMaterial({
          map: moonTex,
          roughness: 0.9,
          metalness: 0.0
      });
      const moon = new THREE.Mesh(moonGeo, moonMat);
      moon.position.set(450, 150, -350); // Orbiting earth relatively
      earth.add(moon);
      
      // 3. Faint Nebula Dust behind constellations
      const nebulaGeo = new THREE.BufferGeometry();
      const nebulaCount = isMobile ? 300 : 800;
      const nebulaPos = new Float32Array(nebulaCount * 3);
      for(let i=0; i<nebulaCount; i++) {
          nebulaPos[i*3] = (Math.random() - 0.5) * 3000;
          nebulaPos[i*3+1] = (Math.random() - 0.5) * 2000;
          nebulaPos[i*3+2] = (Math.random() - 0.5) * 2000 - 500;
      }
      nebulaGeo.setAttribute('position', new THREE.BufferAttribute(nebulaPos, 3));
      
      // Canvas texture for soft dust
      const c = document.createElement('canvas');
      c.width = 32; c.height = 32;
      const ctx = c.getContext('2d');
      const grad = ctx.createRadialGradient(16, 16, 0, 16, 16, 16);
      grad.addColorStop(0, 'rgba(100, 50, 200, 0.4)');
      grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0,0,32,32);
      const dustTex = new THREE.CanvasTexture(c);

      const nebulaMat = new THREE.PointsMaterial({
          size: 150,
          map: dustTex,
          transparent: true,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
          opacity: 0.3
      });
      nebulaParticles = new THREE.Points(nebulaGeo, nebulaMat);
      scene.add(nebulaParticles);
  }

  function init() {
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x000000);
    scene.fog = new THREE.FogExp2(0x000000, 0.0003);
    
    camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 1, 10000);
    camera.position.set(0, 400, 1000);

    renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: false, alpha: false, powerPreference: 'low-power' });
    renderer.setPixelRatio(pixelRatio);
    renderer.setSize(window.innerWidth, window.innerHeight);

    createSpiralGalaxy();
    createNeuralNetwork();
    createPlanets();

    window.addEventListener('resize', onWindowResize);
    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('touchmove', onTouchMove, { passive: true });
    window.addEventListener('scroll', onScroll, { passive: true });
    // Pause rendering when tab is not visible
    document.addEventListener('visibilitychange', () => {
      isPaused = document.hidden;
      if (!isPaused && !animFrameId) animate();
    });

    animate();
  }

  function createSpiralGalaxy() {
    const parameters = {
        count: isMobile ? 10000 : 30000,
        size: isMobile ? 2.0 : 1.5,
        radius: 1200,
        branches: 3,
        spin: 1.5,
        randomness: 0.4,
        randomnessPower: 3,
        insideColor: '#ff6030', 
        outsideColor: '#1b3984' 
    };

    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(parameters.count * 3);
    const colors = new Float32Array(parameters.count * 3);

    const colorInside = new THREE.Color(parameters.insideColor);
    const colorOutside = new THREE.Color(parameters.outsideColor);

    for (let i = 0; i < parameters.count; i++) {
        const i3 = i * 3;
        const radius = Math.random() * parameters.radius;
        const spinAngle = radius * parameters.spin;
        const branchAngle = ((i % parameters.branches) / parameters.branches) * Math.PI * 2;

        const randomX = Math.pow(Math.random(), parameters.randomnessPower) * (Math.random() < 0.5 ? 1 : -1) * parameters.randomness * radius;
        const randomY = Math.pow(Math.random(), parameters.randomnessPower) * (Math.random() < 0.5 ? 1 : -1) * parameters.randomness * radius * 0.4;
        const randomZ = Math.pow(Math.random(), parameters.randomnessPower) * (Math.random() < 0.5 ? 1 : -1) * parameters.randomness * radius;

        positions[i3] = Math.cos(branchAngle + spinAngle) * radius + randomX;
        positions[i3 + 1] = randomY - 100;
        positions[i3 + 2] = Math.sin(branchAngle + spinAngle) * radius + randomZ;

        const mixedColor = colorInside.clone();
        mixedColor.lerp(colorOutside, radius / parameters.radius);
        
        if (Math.random() > 0.95) {
            colors[i3] = 1; colors[i3 + 1] = 1; colors[i3 + 2] = 1;
        } else {
            colors[i3] = mixedColor.r; colors[i3 + 1] = mixedColor.g; colors[i3 + 2] = mixedColor.b;
        }
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const canvas = document.createElement('canvas');
    canvas.width = 16; canvas.height = 16;
    const ctx = canvas.getContext('2d');
    const grad = ctx.createRadialGradient(8, 8, 0, 8, 8, 8);
    grad.addColorStop(0, 'rgba(255,255,255,1)');
    grad.addColorStop(0.3, 'rgba(255,255,255,0.8)');
    grad.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0,0,16,16);
    const starTex = new THREE.CanvasTexture(canvas);

    const material = new THREE.PointsMaterial({
        size: parameters.size,
        sizeAttenuation: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        vertexColors: true,
        map: starTex,
        transparent: true
    });

    particleGalaxy = new THREE.Points(geometry, material);
    particleGalaxy.rotation.x = 0.3;
    particleGalaxy.rotation.z = -0.1;
    scene.add(particleGalaxy);
  }

  function createNeuralNetwork() {
      // 1. Create interactive nodes layer
      const nodeGeo = new THREE.BufferGeometry();
      const nodePos = new Float32Array(nodeCount * 3);
      
      const range = 800;
      for (let i = 0; i < nodeCount; i++) {
          const x = (Math.random() - 0.5) * range * 2;
          const y = (Math.random() - 0.5) * range;
          const z = (Math.random() - 0.5) * range;
          
          nodePos[i * 3] = x;
          nodePos[i * 3 + 1] = y;
          nodePos[i * 3 + 2] = z;

          nodesData.push({
              velocity: new THREE.Vector3((Math.random()-0.5)*0.5, (Math.random()-0.5)*0.5, (Math.random()-0.5)*0.5),
              numConnections: 0
          });
      }
      
      nodeGeo.setAttribute('position', new THREE.BufferAttribute(nodePos, 3));
      
      const nodeMat = new THREE.PointsMaterial({
          color: 0x0ea5e9,
          size: 3,
          blending: THREE.AdditiveBlending,
          transparent: true,
          sizeAttenuation: true,
          opacity: 0.6
      });
      
      interactiveNodes = new THREE.Points(nodeGeo, nodeMat);
      scene.add(interactiveNodes);

      // 2. Create lines buffer geometry (max possible lines)
      linesGeometry = new THREE.BufferGeometry();
      const maxLines = nodeCount * nodeCount;
      const positions = new Float32Array(maxLines * 3);
      const colors = new Float32Array(maxLines * 3);
      
      linesGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      linesGeometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
      
      const linesMat = new THREE.LineBasicMaterial({
          vertexColors: true,
          blending: THREE.AdditiveBlending,
          transparent: true,
          opacity: 0.8
      });
      
      linesMesh = new THREE.LineSegments(linesGeometry, linesMat);
      scene.add(linesMesh);
  }

  function updateNeuralNetwork() {
      if (!interactiveNodes || !linesMesh) return;
      
      const positions = interactiveNodes.geometry.attributes.position.array;
      let vertexpos = 0;
      let colorpos = 0;
      let numConnected = 0;

      const linePositions = linesMesh.geometry.attributes.position.array;
      const lineColors = linesMesh.geometry.attributes.color.array;

      for (let i = 0; i < nodeCount; i++) nodesData[i].numConnections = 0;

      // Project mouse coordinates to 3D plane
      const mouse3D = new THREE.Vector3(pointerX * 600, -pointerY * 400, 200 - scrollY*0.5);
      
      // Update node positions (drifting slowly)
      for (let i = 0; i < nodeCount; i++) {
          nodesData[i].velocity.clampScalar(-1, 1);
          positions[i * 3] += nodesData[i].velocity.x;
          positions[i * 3 + 1] += nodesData[i].velocity.y;
          positions[i * 3 + 2] += nodesData[i].velocity.z;

          // Boundary checks
          if (positions[i * 3] > 800 || positions[i * 3] < -800) nodesData[i].velocity.x *= -1;
          if (positions[i * 3 + 1] > 400 || positions[i * 3 + 1] < -400) nodesData[i].velocity.y *= -1;
          if (positions[i * 3 + 2] > 600 || positions[i * 3 + 2] < -600) nodesData[i].velocity.z *= -1;

          // Avoid mouse
          const nodeVec = new THREE.Vector3(positions[i*3], positions[i*3+1], positions[i*3+2]);
          const distToMouse = nodeVec.distanceTo(mouse3D);
          
          let forceOpacity = 0;
          if (distToMouse < 250) {
              const repel = new THREE.Vector3().subVectors(nodeVec, mouse3D).normalize().multiplyScalar(1.5);
              positions[i * 3] += repel.x;
              positions[i * 3 + 1] += repel.y;
              positions[i * 3 + 2] += repel.z;
              forceOpacity = 1 - (distToMouse / 250); // Glow stronger near mouse
          }

          // Check connections
          for (let j = i + 1; j < nodeCount; j++) {
              const dx = positions[i * 3] - positions[j * 3];
              const dy = positions[i * 3 + 1] - positions[j * 3 + 1];
              const dz = positions[i * 3 + 2] - positions[j * 3 + 2];
              const distSq = dx*dx + dy*dy + dz*dz;
              
              if (distSq < 15000) { // Max connection distance squared
                  // Center Masking: Avoid connecting near the center text
                  const midX = (positions[i * 3] + positions[j * 3]) / 2;
                  const midY = (positions[i * 3 + 1] + positions[j * 3 + 1]) / 2;
                  const distToCenter = Math.sqrt(midX*midX + midY*midY);
                  
                  let centerFade = 1.0;
                  if (distToCenter < 350) {
                      centerFade = Math.max(0, (distToCenter - 150) / 200); // fade out entirely near center
                  }
                  
                  if (centerFade > 0.05) {
                      nodesData[i].numConnections++;
                      nodesData[j].numConnections++;
                      
                      const alpha = ((1.0 - distSq / 15000) * 0.8 + (forceOpacity * 0.5)) * centerFade;
                      
                      linePositions[vertexpos++] = positions[i * 3];
                      linePositions[vertexpos++] = positions[i * 3 + 1];
                      linePositions[vertexpos++] = positions[i * 3 + 2];
                      
                      linePositions[vertexpos++] = positions[j * 3];
                      linePositions[vertexpos++] = positions[j * 3 + 1];
                      linePositions[vertexpos++] = positions[j * 3 + 2];
                      
                      // Color blending (cyan to purple)
                      const r = 0.5 + forceOpacity;
                      const g = 0.2 + alpha;
                      const b = 1.0;

                      lineColors[colorpos++] = r; lineColors[colorpos++] = g; lineColors[colorpos++] = b;
                      lineColors[colorpos++] = r; lineColors[colorpos++] = g; lineColors[colorpos++] = b;
                      
                      numConnected++;
                  }
              }
          }
      }
      
      linesMesh.geometry.setDrawRange(0, numConnected * 2);
      linesMesh.geometry.attributes.position.needsUpdate = true;
      linesMesh.geometry.attributes.color.needsUpdate = true;
      interactiveNodes.geometry.attributes.position.needsUpdate = true;
  }

  function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  }

  function onMouseMove(event) {
    if (isMobile) return;
    const now = performance.now();
    if (now - lastInputTime < INPUT_THROTTLE) return;
    lastInputTime = now;
    pointerX = (event.clientX / window.innerWidth) * 2 - 1;
    pointerY = (event.clientY / window.innerHeight) * 2 - 1;
    targetX = (event.clientX - windowHalfX) * 0.1;
    targetY = (event.clientY - windowHalfY) * 0.1;
  }
  
  function onTouchMove(event) {
    const now = performance.now();
    if (now - lastInputTime < INPUT_THROTTLE) return;
    lastInputTime = now;
    if (event.touches.length === 1) {
      pointerX = (event.touches[0].pageX / window.innerWidth) * 2 - 1;
      pointerY = (event.touches[0].pageY / window.innerHeight) * 2 - 1;
      targetX = (event.touches[0].pageX - windowHalfX) * 0.1;
      targetY = (event.touches[0].pageY - windowHalfY) * 0.1;
    }
  }
  function onScroll() {
    targetScrollY = window.scrollY * 0.15;
  }

  function animate() {
    if (isPaused) { animFrameId = null; return; }
    animFrameId = requestAnimationFrame(animate);

    mouseX += (targetX - mouseX) * 0.04;
    mouseY += (targetY - mouseY) * 0.04;
    scrollY += (targetScrollY - scrollY) * 0.08;

    camera.position.x = mouseX;
    camera.position.y = 400 - mouseY;
    camera.position.z = 1000 - scrollY; 
    camera.lookAt(0, -100, -scrollY * 0.5);

    if (planetsGroup) {
        planetsGroup.children[0].rotation.y += 0.001; // Earth spin
        planetsGroup.children[0].children[0].rotation.y += 0.0012; // Clouds
        planetsGroup.children[0].children[2].rotation.y += 0.002; // Moon orbit
        // Parallax for planets
        planetsGroup.position.x = mouseX * -0.03;
        planetsGroup.position.y = mouseY * 0.03;
    }
    if (nebulaParticles) {
        nebulaParticles.rotation.y -= 0.0001;
    }
    if (particleGalaxy) {
        particleGalaxy.rotation.y -= 0.0003; 
    }
    
    if (interactiveNodes) {
        interactiveNodes.rotation.y -= 0.0003;
        linesMesh.rotation.y -= 0.0003;
        updateNeuralNetwork();
    }

    renderer.render(scene, camera);
  }

  init();
}
