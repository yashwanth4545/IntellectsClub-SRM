// Intellects Club - Projects View

export async function render(container, db, state) {
  let projects = [];
  try {
    projects = await db.getProjects();
  } catch (err) {
    console.error("Failed to load projects:", err);
  }

  // Extract unique categories for filter tabs
  const categories = ['All', ...new Set(projects.map(p => p.category))];

  const filterTabsHtml = categories.map((cat, idx) => `
    <button class="filter-tab ${idx === 0 ? 'active' : ''}" data-category="${cat}">${cat}</button>
  `).join('');

  // Generate projects grid function
  function generateGridHtml(filteredProjects) {
    if (filteredProjects.length === 0) {
      return '<p class="text-muted text-center" style="grid-column: 1/-1; padding: 3rem;">No projects found under this category.</p>';
    }

    return filteredProjects.map(proj => `
      <div class="glass-panel project-card" data-category="${proj.category}">
        <div class="project-img-wrapper">
          <img src="${proj.image_url || 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?q=80&w=800'}" alt="${proj.title}" class="project-image">
          <span class="project-category-badge">${proj.category}</span>
          ${proj.featured ? '<span class="project-featured-badge"><i data-lucide="sparkles"></i> Featured</span>' : ''}
        </div>
        <div class="project-card-body">
          <h3 class="project-title">${proj.title}</h3>
          ${proj.lookingFor && proj.lookingFor.length > 0 ? 
            '<div style="margin-bottom: 0.75rem;">' + proj.lookingFor.map(role => `<span class="project-role-tag"><i data-lucide="user-plus" style="width: 12px; height: 12px; display: inline-block; vertical-align: middle; margin-right: 4px;"></i>Looking for: ${role}</span>`).join(' ') + '</div>' 
            : ''}
          <p class="project-desc">${proj.description}</p>
          
          <div class="project-creators">
            <span class="creators-label">Built By:</span>
            <span class="creators-names">${proj.creators.join(', ')}</span>
          </div>

          <div class="project-links">
            ${proj.github_url ? `<a href="${proj.github_url}" target="_blank" aria-label="GitHub Repository" class="project-link-btn"><i data-lucide="github"></i> Code</a>` : ''}
            ${proj.live_url ? `<a href="${proj.live_url}" target="_blank" aria-label="Live Demo Website" class="project-link-btn primary"><i data-lucide="external-link"></i> Live Demo</a>` : ''}
          </div>
        </div>
      </div>
    `).join('');
  }

  container.innerHTML = `
    <h1 class="page-title">Innovations &amp; Projects</h1>
    <p class="page-subtitle">A showcase of systems, applications, AI models, and robotics research built by Intellects Club members.</p>

    <!-- Filter Category Tabs -->
    <div class="filter-tabs-wrapper">
      ${filterTabsHtml}
    </div>

    <!-- Projects Grid Container -->
    <div class="grid-cols-3 projects-grid" id="projects-grid-container">
      ${generateGridHtml(projects)}
    </div>
  `;

  // Attach filter event listeners
  const gridContainer = container.querySelector('#projects-grid-container');
  const tabs = container.querySelectorAll('.filter-tab');

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      // Toggle active states
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      const selectedCategory = tab.getAttribute('data-category');
      
      // Filter list
      const filtered = selectedCategory === 'All' 
        ? projects 
        : projects.filter(p => p.category === selectedCategory);

      // GSAP Shuffle Transition Animation
      gsap.to(gridContainer, {
        opacity: 0,
        y: 10,
        duration: 0.25,
        onComplete: () => {
          gridContainer.innerHTML = generateGridHtml(filtered);
          lucide.createIcons(); // Refresh icons inside refreshed HTML
          
          // Reinitialize Vanilla Tilt
          if (window.VanillaTilt) {
            window.VanillaTilt.init(document.querySelectorAll(".project-card"), {
                max: 15,
                speed: 400,
                glare: true,
                "max-glare": 0.3
            });
          }

          gsap.to(gridContainer, {
            opacity: 1,
            y: 0,
            duration: 0.4,
            ease: 'power2.out'
          });
        }
      });
    });
  });

  // Initialize Vanilla Tilt
  if (window.VanillaTilt) {
    window.VanillaTilt.init(document.querySelectorAll(".project-card"), {
        max: 15,
        speed: 400,
        glare: true,
        "max-glare": 0.3
    });
  }

  // Entrance animations for initial load
  gsap.from('.project-card', {
    opacity: 0,
    y: 30,
    stagger: 0.08,
    duration: 0.5,
    ease: 'power3.out'
  });
}
