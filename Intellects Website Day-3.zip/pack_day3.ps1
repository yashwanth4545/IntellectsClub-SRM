$source = 'D:\Intellects Club-Website'
$staging = 'D:\Intellects Website Day-3'
$zipPath = 'D:\Intellects Website Day-3.zip'

If (Test-Path $staging) { Remove-Item $staging -Recurse -Force }
New-Item -ItemType Directory -Path $staging | Out-Null

$files = Get-ChildItem -Path $source -Recurse -File | Where-Object { 
    $_.LastWriteTime.Date -eq (Get-Date).Date -and 
    $_.Extension -ne '.py' -and 
    $_.Extension -ne '.cache' -and 
    $_.DirectoryName -notmatch '\\scratch' -and 
    $_.DirectoryName -notmatch '\\\.firebase' 
}

foreach ($file in $files) { 
    $relativePath = $file.FullName.Substring($source.Length + 1)
    $destPath = Join-Path $staging $relativePath
    $destDir = Split-Path $destPath
    if (-not (Test-Path $destDir)) { 
        New-Item -ItemType Directory -Path $destDir -Force | Out-Null 
    }
    Copy-Item $file.FullName -Destination $destPath 
}

$readmeContent = @"
Intellects Website Day-3 Updates
================================

Today's work focused on advanced performance optimization, UX refinement, and bug fixes:

1. Performance Enhancements:
   - Reduced 3D galaxy particles for significant GPU savings.
   - Disabled anti-aliasing and enabled low-power preference for the WebGL renderer.
   - Throttled input events to avoid excessive frame recalculations.
   - Added Page Visibility API to pause rendering when the tab is inactive.
   - Changed stat counters to requestAnimationFrame for smooth animations.
   
2. Network & Loading Optimization:
   - Removed aggressive cache-busting to utilize browser module caching.
   - Added lazy loading to images.
   
3. Bug Fixes & UX:
   - Deduplicated VanillaTilt initialization.
   - Optimized custom cursor animation.
   - Fixed MutationObserver memory leak.
   - Removed a heavy blur filter from page transitions.
   - Cropped text from the main glass medallion logo.

4. Deployment:
   - Successfully deployed the v2-upgrade build.

5. Project Security Features Overview:
   - Database Firewall (RLS): Supabase Row Level Security blocks unauthorized database access. Only admins can edit events/projects; users can only edit their own data.
   - User Authentication: Supabase Auth securely manages passwords and Google logins without storing plain text.
   - Role-Based Access Control (RBAC): Profiles have 'admin' or 'member' roles, separating leader access from student access.
   - Protected Pages: Frontend route guards block logged-out users from accessing private dashboards.
   - Automated Secure Triggers: Database triggers automatically and securely generate profiles on signup.
   - Cache Security: Firebase Hosting headers block caching of sensitive JS code on shared lab computers.
"@

Set-Content -Path (Join-Path $staging 'README.txt') -Value $readmeContent

If (Test-Path $zipPath) { Remove-Item $zipPath -Force }
Compress-Archive -Path "$staging\*" -DestinationPath $zipPath
Remove-Item $staging -Recurse -Force
Write-Output "Zip created successfully at $zipPath"
