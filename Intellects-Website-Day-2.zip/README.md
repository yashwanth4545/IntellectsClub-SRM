# SRM Intellects Club Website - Day 2 Rollout (Social Links Integration & Cache Controls)

This folder contains the core files implemented and modified during **Day 2** of development for the official SRM Intellects Club website. It contains only the files updated for this rollout to prevent uploading configuration files or sensitive credentials.

## 🚀 Features Implemented (Day 2 Updates)

1. **Integration of Real Social Media Profiles**:
   - Updated the `SEED_TEAM` database with the actual GitHub and LinkedIn profiles for:
     * **Karthik S** (President)
     * **Mayank** (Vice President)
     * **Hari Supriya** (Technical Co-Lead)
   - These updates resolve the previous placeholder (`https://github.com` & `https://linkedin.com`) state.

2. **Fixed Browser Caching Policies**:
   - Configured `firebase.json` with a dedicated header block enforcing `Cache-Control: no-cache, no-store, must-revalidate` for `app.js`, `db.js`, and `style.css`.
   - This ensures that any future team profile updates deployed on the database go live **instantly** for all users, completely bypassing browser and CDN caches without needing manual version tag adjustments in the code!

3. **All Day 1 Features Included**:
   - Hierarchical grid layout for all 12 core board members and mentors.
   - Dynamic custom badge logic supporting your **Site Developer** tag.
   - GSAP animation conflict resolutions and SPA transition scroll cleanups.

---

## 📂 Backup Folder Structure

```text
├── index.html          # Main HTML entry point (updated script version parameters)
├── app.js              # SPA router configuration, GSAP transitions, and scroll resets
├── db.js               # Updated database seed with live social media profile URLs
├── style.css           # Styling for grid layouts, badges, and smooth mouse-over shadows
├── README.md           # This summary file
├── assets/
│   └── team/           # Directory holding the core board member profile images
└── views/
    ├── team-v2.js      # Active Team View rendering dynamic profile cards
    └── team.js         # Legacy/Fallback Team View layout code
```

---

*Developed by GUDIBANDI YASHWANTH REDDY (Technical & Innovation).*
