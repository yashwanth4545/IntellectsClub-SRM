# SRM Intellects Club Website - Day 1 Rollout (Team Profiles)

This folder contains the core files implemented and modified during **Day 1** of development for the official SRM Intellects Club website. It contains only the files updated for this rollout to prevent uploading configuration files or sensitive credentials.

## 🚀 Features Implemented

1. **Premium Team Profile Grid**:
   - Clean, modern layout arranging all 12 core board members and mentors in hierarchical order.
   - Individual profile cards showing names, highlighted badge pills for roles, and interactive links.

2. **Site Developer Badge**:
   - Built a dynamic badge system supporting custom tags.
   - Added a unique **Site Developer** badge to GUDIBANDI YASHWANTH REDDY's profile.

3. **Smooth 3D Hover Tilt & Glows**:
   - Implemented an interactive mouse-tilt effect on each card.
   - Fixed a critical CSS transition clash where the browser's `.glass-panel` transition fought with GSAP entrance animations, freezing card opacities.

4. **SPA Navigation Cleanups**:
   - Modified `app.js` routing logic to automatically clear/kill old GSAP `ScrollTrigger` instances.
   - Reset browser window scroll state to the top *before* rendering new pages to prevent premature scroll-animation triggers.

5. **Cache-Busting Controls**:
   - Integrated version-based query parameters (`?v=x.x`) to force browsers to load the fresh database and routing files.

---

## 📂 Backup Folder Structure

```text
├── index.html          # Main HTML entry point with cache invalidation scripts
├── app.js              # SPA router configuration, GSAP transitions, and scroll resets
├── db.js               # Database seed containing team member details (links, roles, descriptions)
├── style.css           # Styling for grid layouts, badges, and smooth mouse-over shadows
├── assets/
│   └── team/           # Directory holding the core board member profile images
└── views/
    ├── team-v2.js      # Active Team View rendering dynamic profile cards
    └── team.js         # Legacy/Fallback Team View layout code
```

---

*Developed by GUDIBANDI YASHWANTH REDDY (Technical & Innovation).*
