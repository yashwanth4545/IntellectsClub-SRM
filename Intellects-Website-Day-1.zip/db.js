// Intellects Club - Database Abstraction Layer (Supabase, Firebase & Mock Fallback)
import config from './config.js';

let supabase = null;

let firebaseApp = null;
let firestore = null;

// Initialize Supabase if keys are provided
if (config.supabaseUrl && config.supabaseAnonKey) {
  try {
    supabase = window.supabase.createClient(config.supabaseUrl, config.supabaseAnonKey);
    console.log("Supabase Client initialized successfully.");
  } catch (err) {
    console.error("CRITICAL: Failed to initialize Supabase:", err);
  }
} else {
  console.error("CRITICAL: No Supabase credentials found in config.js.");
}

// Initialize Firebase if keys are provided
if (config.firebaseConfig && config.firebaseConfig.apiKey) {
  try {
    firebaseApp = window.firebase.initializeApp(config.firebaseConfig);
    firestore = window.firebase.firestore();
    console.log("Firebase & Firestore initialized successfully.");
  } catch (err) {
    console.error("Failed to initialize Firebase:", err);
  }
} else {
  console.log("No Firebase credentials found in config.js.");
}

/* ==========================================================================
   MOCK DATABASE SEED DATA & ENGINE
   ========================================================================== */

const SEED_ANNOUNCEMENTS = [
  {
    id: "ann-1",
    title: "AI Build-a-thon registrations are open!",
    content: "Register now for the flagship AI hackathon at SRM Ramapuram. Build agents, show off prototypes, and win prizes.",
    type: "success",
    created_at: new Date(Date.now() - 3600000).toISOString()
  },
  {
    id: "ann-2",
    title: "Weekly Hands-on Workshop: PyTorch basics",
    content: "Join us this Friday at Lab 3, 2:00 PM to learn the fundamentals of building and training neural networks.",
    type: "info",
    created_at: new Date(Date.now() - 86400000).toISOString()
  }
];

const SEED_EVENTS = [
  {
    id: "evt-1",
    title: "Introduction to Generative AI & LLMs",
    description: "A comprehensive deep dive into Large Language Models, prompt engineering, and building apps using OpenAI and Hugging Face APIs.",
    date: "2026-07-24",
    time: "14:00",
    venue: "Main Campus Auditorium, SRM Ramapuram",
    registration_limit: 100,
    image_url: "https://images.unsplash.com/photo-1677442136019-21780efad99a?q=80&w=800",
    status: "upcoming"
  },
  {
    id: "evt-2",
    title: "Web3 & Decentralized Applications",
    description: "Learn how to build smart contracts and connect them with front-end React apps in our first hybrid developer workshop.",
    date: "2026-08-10",
    time: "10:30",
    venue: "Tech Lab 5, Block V",
    registration_limit: 50,
    image_url: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?q=80&w=800",
    status: "upcoming"
  },
  {
    id: "evt-3",
    title: "Git, GitHub, and Open Source Contributions",
    description: "Our launch event teaching version control, branch management, pull requests, and how to kickstart your open source journey.",
    date: "2026-06-15",
    time: "09:00",
    venue: "Seminar Hall, Block III",
    registration_limit: 120,
    image_url: "https://images.unsplash.com/photo-1618401471353-b98aedd07871?q=80&w=800",
    status: "past"
  }
];

const SEED_PROJECTS = [
  {
    id: "proj-1",
    title: "NeuralFlow Visualizer",
    description: "An interactive, web-based tool to build, visualize, and inspect custom neural network topologies in real-time.",
    image_url: "https://images.unsplash.com/photo-1507668077129-56e32842fceb?q=80&w=800",
    github_url: "https://github.com/intellects-srm/neuralflow",
    live_url: "https://neuralflow.intellectsclub.in",
    creators: ["Harish R", "Tanmay K"],
    category: "Artificial Intelligence",
    featured: true
  },
  {
    id: "proj-2",
    title: "SRM Ramapuram GPA Predictor",
    description: "A micro-tool designed to calculate CGPA and predict future semester targets using historical grade thresholds.",
    image_url: "https://images.unsplash.com/photo-1543269865-cbf427effbad?q=80&w=800",
    github_url: "https://github.com/intellects-srm/gpa-predict",
    live_url: "https://gpa.intellectsclub.in",
    creators: ["Preeti S", "Aditya G"],
    category: "Software Utility",
    featured: true
  },
  {
    id: "proj-3",
    title: "AeroAI Autonomous Drone Navigation",
    description: "A research project focusing on reinforcement learning algorithms for visual obstacle avoidance on miniature UAVs.",
    image_url: "https://images.unsplash.com/photo-1508614589041-895b88991e3e?q=80&w=800",
    github_url: "https://github.com/intellects-srm/aero-ai",
    live_url: null,
    creators: ["Rahul M", "Vikram V"],
    category: "Robotics & AI",
    featured: false
  }
];

const SEED_TEAM = [
  {
    name: "Karthik S",
    role: "President",
    image: "/assets/team/Karthik.jpg",
    description: "Leading the club's vision and ensuring successful execution of all strategic initiatives.",
    github: "https://github.com/karthik7srm",
    linkedin: "https://www.linkedin.com/in/7karthiks/?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base_contact_details%3BDc1VGLJLQiKglHaM7AV1Ng%3D%3D"
  },
  {
    name: "Mayank",
    role: "Vice President",
    image: "/assets/team/Mayank Vice President.jpg",
    description: "Assisting the president in day-to-day operations and overseeing team collaboration.",
    github: "https://github.com/Mayankgupta645",
    linkedin: "https://www.linkedin.com/in/mayank-guptai"
  },
  {
    name: "Krishna Kar",
    role: "Secretary",
    image: "/assets/team/Krishna Kar.jpg",
    description: "Managing club records, communication, and coordinating meetings effectively.",
    github: "https://github.com",
    linkedin: "https://linkedin.com"
  },
  {
    name: "Darshan S",
    role: "Vice Secretary",
    image: "/assets/team/Darshan S Vise Secretary.jpg",
    description: "Supporting the secretary with documentation, scheduling, and member communication.",
    github: "https://github.com",
    linkedin: "https://linkedin.com"
  },
  {
    name: "GUDIBANDI YASHWANTH REDDY",
    role: "Technical & Innovation",
    image: "/assets/team/GUDIBANDI YASHWANTH REDDY.jpg",
    description: "Architect and lead developer of the official SRM Intellects Club digital ecosystem.",
    github: "https://github.com",
    linkedin: "https://linkedin.com",
    siteCreator: true,
    specialTag: "Site Developer"
  },
  {
    name: "Akansha",
    role: "Technical Lead",
    image: "/assets/team/Akansha Technical Lead.jpg",
    description: "Spearheading technical projects, workshops, and driving engineering excellence.",
    github: "https://github.com",
    linkedin: "https://linkedin.com"
  },
  {
    name: "Hari Supriya",
    role: "Technical Co-Lead",
    image: "/assets/team/Hari Supriya Technical Co Lead.jpg",
    description: "Co-leading technical initiatives and mentoring members in cutting-edge technologies.",
    github: "https://github.com/Henix285",
    linkedin: "https://www.linkedin.com/in/hari-supriya-daraboina-799618327"
  },
  {
    name: "Yogesh",
    role: "Social Media Lead",
    image: "/assets/team/Yogesh Social Lead.jpg",
    description: "Curating online presence, community engagement, and digital branding.",
    github: "https://github.com",
    linkedin: "https://linkedin.com"
  },
  {
    name: "Arpit",
    role: "Social Media Co-Lead",
    image: "/assets/team/Arpit Social Media Co Lead.jpg",
    description: "Assisting in content creation, campaign management, and digital outreach.",
    github: "https://github.com",
    linkedin: "https://linkedin.com"
  },
  {
    name: "Grishma",
    role: "Event Management Lead",
    image: "/assets/team/Grishma Event Management Lead.jpg",
    description: "Planning and organizing club events, ensuring seamless execution from start to finish.",
    github: "https://github.com",
    linkedin: "https://linkedin.com"
  },
  {
    name: "Jai Karthik",
    role: "Event Management Co-Lead",
    image: "/assets/team/Jai Karthik Event Management Co Lead.jpg",
    description: "Co-organizing events and managing logistics for all club activities.",
    github: "https://github.com",
    linkedin: "https://linkedin.com"
  },
  {
    name: "Tanishqa",
    role: "Creative Lead",
    image: "/assets/team/Tanishqa Creative Lead.jpg",
    description: "Leading the creative direction, designing assets, and ensuring visual excellence.",
    github: "https://github.com",
    linkedin: "https://linkedin.com"
  },
  {
    name: "Nilesh",
    role: "Creative Co-Lead",
    image: "/assets/team/Nilesh Creative Co Lead.jpg",
    description: "Collaborating on design projects, generating creative ideas, and producing visual content.",
    github: "https://github.com",
    linkedin: "https://linkedin.com"
  }
];

const SEED_GALLERY = [
  { id: "gal-1", title: "Git Workshop Hands-on", image_url: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=800", category: "Workshops", date: "2026-06-15" },
  { id: "gal-2", title: "Club Orientation Day", image_url: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=800", category: "Core Meetings", date: "2026-06-05" },
  { id: "gal-3", title: "National Level AI Hackathon Winners", image_url: "https://images.unsplash.com/photo-1523240795612-9a054b0db644?q=80&w=800", category: "Achievements", date: "2026-05-20" }
];

const SEED_REQUESTS = [
  {
    id: "req-1",
    full_name: "Abhinav Raja",
    email: "abhinav@example.com",
    register_number: "SRM12345",
    department: "Computer Science",
    year_of_study: 2,
    skills: ["Python", "HTML/CSS"],
    interest_statement: "I want to explore AI models and collaborate with peers to build real-world systems beyond theory classes.",
    status: "pending",
    created_at: new Date(Date.now() - 172800000).toISOString()
  },
  {
    id: "req-2",
    full_name: "Dhruv Sharma",
    email: "dhruv@example.com",
    register_number: "SRM98765",
    department: "Information Technology",
    year_of_study: 3,
    skills: ["Javascript", "React", "Node.js"],
    interest_statement: "I'm interested in joining the web dev team to build full-stack web architectures for club projects.",
    status: "approved",
    created_at: new Date(Date.now() - 345600000).toISOString()
  }
];

const SEED_REGISTRATIONS = [
  {
    id: "reg-1",
    event_id: "evt-1",
    full_name: "Meera Krishnan",
    email: "meera@example.com",
    register_number: "SRM44332",
    department: "Electronics & Communication",
    year_of_study: 3,
    status: "confirmed",
    created_at: new Date().toISOString()
  }
];

// Initialize localStorage engine helper
function getLocal(key, defaultValue) {
  const data = localStorage.getItem(key);
  if (!data) {
    localStorage.setItem(key, JSON.stringify(defaultValue));
    return defaultValue;
  }
  return JSON.parse(data);
}

function setLocal(key, data) {
  localStorage.setItem(key, JSON.stringify(data));
}

// Seed mock DB if not existing

/* ==========================================================================
   DATABASE ACCESS INTERFACE
   ========================================================================== */

export const db = {
  // Check Mode

  // Announcements API (Routed to Firebase Firestore)
  async getAnnouncements() {
    try {
      const snapshot = await firestore.collection('announcements').orderBy('created_at', 'desc').get();
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
      console.error("Firestore getAnnouncements error:", error);
      throw error;
    }
  },

  async addAnnouncement(announcement) {
    try {
      const annWithDate = { ...announcement, created_at: new Date().toISOString() };
      const docRef = await firestore.collection('announcements').add(annWithDate);
      return { id: docRef.id, ...annWithDate };
    } catch (error) {
      console.error("Firestore addAnnouncement error:", error);
      throw error;
    }
  },

  // Events API
  async getEvents() {
    const { data, error } = await supabase
      .from('events')
      .select('*')
      .order('date', { ascending: true });
    if (error) throw error;
    return data;
  },

  async addEvent(event) {
    const { data, error } = await supabase
      .from('events')
      .insert([event])
      .select();
    if (error) throw error;
    return data[0];
  },

  // Registrations API
  async registerForEvent(registration) {
    const { data, error } = await supabase
      .from('registrations')
      .insert([registration])
      .select();
    if (error) throw error;
    return data[0];
  },

  async getRegistrations() {
    const { data, error } = await supabase
      .from('registrations')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data;
  },

  // Projects API
  async getProjects() {
    const { data, error } = await supabase
      .from('projects')
      .select('*')
      .order('featured', { ascending: false });
    if (error) throw error;
    return data;
  },

  async addProject(project) {
    const { data, error } = await supabase
      .from('projects')
      .insert([project])
      .select();
    if (error) throw error;
    return data[0];
  },

  // Team API (Hardcoded since team structure changes rarely via CMS)
  async getTeam() {
    return SEED_TEAM;
  },

  // Gallery API
  async getGallery() {
    const { data, error } = await supabase
      .from('gallery')
      .select('*')
      .order('date', { ascending: false });
    if (error) throw error;
    return data;
  },

  async addGalleryItem(item) {
    const { data, error } = await supabase
      .from('gallery')
      .insert([item])
      .select();
    if (error) throw error;
    return data[0];
  },

  // Membership Requests API
  async submitRequest(request) {
    const { error } = await supabase
      .from('requests')
      .insert([request]);
    if (error) throw error;

    // Trigger Email Webhook asynchronously
    if (config.googleAppsScriptWebhookUrl) {
      fetch(config.googleAppsScriptWebhookUrl, {
        method: 'POST',
        mode: 'no-cors',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify({ action: 'new_application', data: request })
      }).catch(err => console.error("Webhook trigger failed:", err));
    }

    return request;
  },

  async getRequests() {
    const { data, error } = await supabase
      .from('requests')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data;
  },

  // Used by the public Tracking Page
  async searchRequest(query) {
    const isEmail = query.includes('@');
    const column = isEmail ? 'email' : 'register_number';
    const { data, error } = await supabase
      .from('requests')
      .select('*')
      .eq(column, query)
      .order('created_at', { ascending: false })
      .limit(1);
    return { data, error };
  },

  async updateRequestStatus(id, status, feedback = '') {
    const { data, error } = await supabase
      .from('requests')
      .update({ status, feedback })
      .eq('id', id);

    if (error) return { error };
    return { error: null };
  },

  /* ==========================================================================
     AUTH OPERATIONS
     ========================================================================== */

  async login(email, password) {

    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) return { user: null, error };

    // Get user profile role
    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', data.user.id)
      .single();

    const mergedUser = {
      ...data.user,
      user_metadata: {
        ...data.user.user_metadata,
        role: profile?.role || 'member'
      }
    };
    return { user: mergedUser, error: null };
  },

  async register(email, password, fullName) {

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: fullName
        }
      }
    });
    return { user: data.user, error };
  },

  async signInWithGoogle() {

    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: window.location.origin + '/'
      }
    });
    return { data, error };
  },

  async logout() {
    const { error } = await supabase.auth.signOut();
    return { error };
  },

  async getCurrentUser() {

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;

    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single();

    return {
      ...user,
      user_metadata: {
        ...user.user_metadata,
        role: profile?.role || 'member'
      }
    };
  }
};
