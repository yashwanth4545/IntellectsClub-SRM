// Intellects Club - Main Application & SPA Router
import { db } from './db.js?v=9.4';
import { initThreeBackground } from './components/three-bg.js';
import { initBackgroundQuotes } from './components/background-quotes.js';

// Global Application State
const state = {
  user: null,
  currentRoute: 'home',
  isTransitioning: false
};

// Route mapping
const routes = {
  'home': './views/home.js',
  'about': './views/about.js',
  'team': './views/team-v2.js',
  'events': './views/events.js',
  'gallery': './views/gallery.js',
  'requests': './views/requests.js',
  'contact': './views/contact.js',
  'login': './views/login.js',
  'member': './views/member.js',
  'status': './views/status.js'
};

/* ==========================================================================
   INITIALIZATION & KICKSTART
   ========================================================================== */

document.addEventListener('DOMContentLoaded', async () => {
  // 1. Initialize background animations
  initThreeBackground();
  initBackgroundQuotes();

  // 2. Fetch authenticated session
  try {
    state.user = await db.getCurrentUser();
    updateNavigationForAuth();
  } catch (err) {
    console.error("Error fetching user session:", err);
  }

  // 3. Play Cinematic Intro & reveal app
  playCinematicIntro();

  // 4. Hook Navigation and Routing
  window.addEventListener('hashchange', handleRouting);
  setupNavigationEvents();
});

/* ==========================================================================
   CINEMATIC INTRO ANIMATION (GSAP)
   ========================================================================== */

function playCinematicIntro() {
  const intro = document.getElementById('cinematic-intro');
  const titleChars = document.querySelectorAll('#intro-title .char');
  const subtitle = document.getElementById('intro-subtitle');
  const header = document.getElementById('site-header');
  const appRoot = document.getElementById('app-root');
  const footer = document.getElementById('site-footer');

  // GSAP animation timeline
  const tl = gsap.timeline({
    onComplete: () => {
      // Hide intro and show app core
      intro.style.display = 'none';
      header.classList.remove('hidden');
      appRoot.classList.remove('hidden');
      footer.classList.remove('hidden');
      
      // Animate app core entrance
      gsap.fromTo(header, { y: -50, opacity: 0 }, { y: 0, opacity: 1, duration: 0.8, ease: 'power4.out' });
      gsap.fromTo(appRoot, { opacity: 0 }, { opacity: 1, duration: 1.2, ease: 'power2.out' });
      
      // Perform initial routing
      handleRouting();
    }
  });

  // Letter by letter logo reveal (glow + rise)
  tl.to(titleChars, {
    opacity: 1,
    y: 0,
    duration: 0.8,
    stagger: 0.08,
    ease: 'back.out(1.7)'
  });

  // Reveal subtitle
  tl.to(subtitle, {
    opacity: 1,
    letterSpacing: '0.45rem',
    duration: 0.6,
    ease: 'power2.out'
  }, "-=0.3");

  // Fade out intro overlay
  tl.to(intro, {
    opacity: 0,
    duration: 1,
    ease: 'power3.inOut',
    delay: 0.8
  });
}

/* ==========================================================================
   SPA ROUTER (Dynamic Module Loading & GSAP Transitions)
   ========================================================================== */

async function handleRouting() {
  if (state.isTransitioning) return;

  const appRoot = document.getElementById('app-root');
  
  // Extract route key from hash (e.g. #/about -> about)
  let hash = window.location.hash || '#/';
  let routeKey = hash.replace(/^#\/?/, '').split('?')[0] || 'home';

  // (Admin route was removed entirely as it moved to IntellectsConnect)

  // Route guarding (member check)
  if (routeKey === 'member') {
    if (!state.user) {
      showToast("Please log in to access your dashboard.", "error");
      window.location.hash = '#/login';
      return;
    }
  }

  // Fallback to home if page doesn't exist
  if (!routes[routeKey]) {
    routeKey = 'home';
  }

  state.currentRoute = routeKey;
  state.isTransitioning = true;

  // Active navigation highlight
  updateActiveNavLink(routeKey);

  // Close mobile navigation on selection
  document.getElementById('main-nav').classList.remove('open');
  const navBtnIcon = document.querySelector('#mobile-nav-btn i');
  if (navBtnIcon) {
    navBtnIcon.setAttribute('data-lucide', 'menu');
    lucide.createIcons();
  }

  // Dynamic import and page transition
  try {
    const modulePath = routes[routeKey];
    
    // Outgoing transition animation
    await gsap.to(appRoot, { opacity: 0, y: 15, duration: 0.3, ease: 'power2.in' });

    // Scroll to top BEFORE rendering to prevent premature ScrollTrigger activations
    window.scrollTo({ top: 0, behavior: 'instant' });

    // Kill all existing ScrollTriggers before rendering the new page
    if (typeof ScrollTrigger !== 'undefined') {
      ScrollTrigger.getAll().forEach(t => t.kill());
    }

    // Import view module with dynamic timestamp to completely bypass cache for real auth
    const viewModule = await import(modulePath + '?t=' + Date.now());
    
    // Render and inject view HTML
    appRoot.innerHTML = '';
    await viewModule.render(appRoot, db, state);

    // Refresh UI icons
    lucide.createIcons();

    // Incoming transition animation
    await gsap.fromTo(appRoot, 
      { opacity: 0, y: -15 }, 
      { opacity: 1, y: 0, duration: 0.5, ease: 'power3.out' }
    );

  } catch (err) {
    console.error("Routing error for:", routeKey, err);
    appRoot.innerHTML = `
      <section class="glass-panel text-center" style="margin-top: 4rem;">
        <h2 style="font-family: var(--font-heading); color: var(--accent-pink);">Error Loading Page</h2>
        <p style="margin: 1rem 0; color: var(--text-secondary);">We encountered an error loading the requested view module.</p>
        <a href="#/" class="btn-primary">Return Home</a>
      </section>
    `;
    gsap.to(appRoot, { opacity: 1, duration: 0.3 });
  } finally {
    state.isTransitioning = false;
  }
}

/* ==========================================================================
   NAVIGATION & UI EVENT HANDLERS
   ========================================================================== */

function setupNavigationEvents() {
  const mobileNavBtn = document.getElementById('mobile-nav-btn');
  const mainNav = document.getElementById('main-nav');

  // Mobile nav toggler
  mobileNavBtn.addEventListener('click', () => {
    const isOpen = mainNav.classList.toggle('open');
    const iconName = isOpen ? 'x' : 'menu';
    const iconEl = mobileNavBtn.querySelector('i');
    if (iconEl) {
      iconEl.setAttribute('data-lucide', iconName);
      lucide.createIcons();
    }
  });

  // Close nav on clicking background container
  document.addEventListener('click', (e) => {
    if (!mainNav.contains(e.target) && !mobileNavBtn.contains(e.target) && mainNav.classList.contains('open')) {
      mainNav.classList.remove('open');
      const iconEl = mobileNavBtn.querySelector('i');
      if (iconEl) {
        iconEl.setAttribute('data-lucide', 'menu');
        lucide.createIcons();
      }
    }
  });
}

function updateActiveNavLink(routeKey) {
  const links = document.querySelectorAll('.nav-link');
  links.forEach(link => {
    const route = link.getAttribute('data-route');
    if (route === routeKey) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });
}

export function updateNavigationForAuth() {
  const memberItem = document.querySelector('.member-nav-item');
  const authBtn = document.getElementById('login-nav-btn');

  if (state.user) {
    if (memberItem) memberItem.classList.remove('hidden');
    
    // Change Login link to Logout behavior
    authBtn.innerHTML = '<i data-lucide="log-out" class="nav-icon"></i> Logout';
    authBtn.href = '#/login'; // Will trigger logout inside login controller
    authBtn.setAttribute('data-route', 'logout');
  } else {
    if (memberItem) memberItem.classList.add('hidden');
    authBtn.innerHTML = 'Login';
    authBtn.href = '#/login';
    authBtn.setAttribute('data-route', 'login');
  }
}

/* ==========================================================================
   GLOBAL UTILITIES: TOASTS
   ========================================================================== */

export function showToast(message, type = 'info') {
  // Create toast container if not exists
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  // Create toast node
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  
  const iconName = type === 'success' ? 'check-circle' : type === 'error' ? 'alert-triangle' : 'info';
  
  toast.innerHTML = `
    <i data-lucide="${iconName}"></i>
    <span>${message}</span>
  `;

  container.appendChild(toast);
  lucide.createIcons();

  // Remove toast after 4s
  setTimeout(() => {
    gsap.to(toast, {
      opacity: 0,
      x: 100,
      duration: 0.4,
      onComplete: () => toast.remove()
    });
  }, 4000);
}
