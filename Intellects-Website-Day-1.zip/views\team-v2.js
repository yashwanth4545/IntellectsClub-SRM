// Intellects Club - Team View

export async function render(container, db, state) {
  let team = [];
  try {
    team = await db.getTeam();
  } catch (err) {
    console.error("Failed to load team data:", err);
  }

  const teamHtml = team.map(member => {
    const badgeText = member.specialTag || (member.siteCreator ? 'Site Creator' : '');
    const badge = badgeText ? `
      <div class="site-creator-badge">
        <i data-lucide="code-2" style="width:12px;height:12px;"></i>
        <span>${badgeText}</span>
      </div>
    ` : '';

    return `
      <div class="glass-panel team-card team-card--creator">
        ${badge}
        <div class="team-image-container">
          <img src="${member.image}" alt="${member.name}" class="team-image" loading="eager">
          <div class="team-overlay-glow"></div>
        </div>
        <h3 class="team-name">${member.name}</h3>
        <div class="team-role-badge">${member.role}</div>
        <p class="team-desc">${member.description || ''}</p>
        <div class="team-socials">
          ${member.linkedin ? `<a href="${member.linkedin}" target="_blank" aria-label="${member.name} LinkedIn Profile" class="team-social-link linkedin"><i data-lucide="linkedin"></i></a>` : ''}
          ${member.github ? `<a href="${member.github}" target="_blank" aria-label="${member.name} GitHub Profile" class="team-social-link github"><i data-lucide="github"></i></a>` : ''}
        </div>
      </div>
    `;
  }).join('');

  container.innerHTML = `
    <h1 class="page-title">Core Board &amp; Mentors</h1>
    <p class="page-subtitle">Meet the team of students, developers, and advisors driving artificial intelligence and engineering excellence at SRM Ramapuram.</p>

    <div class="team-grid-uniform">
      ${teamHtml}
    </div>
  `;

  // Apply premium 3D Hover tilt effect to team cards
  const cards = container.querySelectorAll('.team-card');
  cards.forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      const rotateX = -(y - centerY) / 8;
      const rotateY = (x - centerX) / 8;

      card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-5px)`;
      card.style.boxShadow = `0 0 40px rgba(251, 191, 36, 0.3), 0 15px 35px rgba(168, 85, 247, 0.25)`;
    });

    card.addEventListener('mouseleave', () => {
      card.style.transform = `perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0px)`;
      card.style.boxShadow = `0 0 25px rgba(251, 191, 36, 0.15), 0 8px 32px 0 rgba(0, 0, 0, 0.37)`;
      card.style.transition = 'transform 0.4s ease-out, box-shadow 0.4s ease-out';
    });

    card.addEventListener('mouseenter', () => {
      card.style.transition = 'none';
    });
  });

  // Entrance animation for cards
  gsap.from('.team-card', {
    opacity: 0,
    y: 35,
    stagger: 0.1,
    duration: 0.6,
    ease: 'power3.out'
  });
}
